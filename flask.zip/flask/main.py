from flask import Flask , render_template,request
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/medicare'
db = SQLAlchemy(app)


class Contact(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(20), nullable=False)
    mob= db.Column(db.String(12), nullable=False)
    msg = db.Column(db.String(120), nullable=False)
    date = db.Column(db.String(12), nullable=True)


class Register(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    u_name = db.Column(db.String(80), nullable=False)
    f_name = db.Column(db.String(30), nullable=False)
    l_name = db.Column(db.String(70), nullable=False)
    pwd = db.Column(db.String(80), nullable=False)
    c_pwd = db.Column(db.String(80), nullable=False)
    Email = db.Column(db.String(20), nullable=False)
    date = db.Column(db.String(12), nullable=True)




@app.route('/',methods=['GET','POST'])
def home():
    return render_template('home.html')

@app.route('/about',methods=['GET','POST'])
def about():
    return render_template('about.html')

@app.route('/contact',methods=['GET','POST'])
def contact():
    if(request.method=='POST'):
        name=request.form.get('name')
        email = request.form.get('email')
        mob = request.form.get('mobile')
        message = request.form.get('mess')
        entry = Contact(name=name,email = email, mob = mob, msg = message, date= datetime.now())
        db.session.add(entry)
        db.session.commit()
    return render_template('contact.html')



@app.route('/visual',methods=['GET','POST'])
def visual():
    return render_template('visual.html')

@app.route('/register',methods=['GET','POST'])
def register():
    if(request.method=='POST'):
        un = request.form.get('uname')
        fn = request.form.get('fname')
        ln = request.form.get('lname')
        passwd = request.form.get('pwd')
        cpass = request.form.get('cpwd')
        email = request.form.get('email')
        entry = Register(u_name = un, f_name = fn, l_name = ln, pwd = passwd, c_pwd = cpass, Email = email, date= datetime.now())
        db.session.add(entry)
        db.session.commit()
    return render_template('Register.html')

                                                                            
@app.route('/biotic',methods=['GET','POST'])
def biotic():
    return render_template('antibiotic.html')

@app.route('/hist',methods=['GET','POST'])
def hist():
    return render_template('antihist.html')

@app.route('/gesic',methods=['GET','POST'])
def gesic():
    return render_template('analgesic.html')

@app.route('/dep',methods=['GET','POST'])
def dep():
    return render_template('antidep.html')

@app.route('/sulfa',methods=['GET','POST'])
def sulfa():
    return render_template('sulfa.html')

@app.route('/acid',methods=['GET','POST'])
def acid():
    return render_template('acid.html')

@app.route('/tranq',methods=['GET','POST'])
def tranq():
    return render_template('tranq.html')
    

app.run(debug=True)
