
.. code:: ipython3

    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import seaborn as sns
    %matplotlib inline

.. code:: ipython3

    df = pd.read_excel('Book.xlsx')

.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Antibiotics</th>
          <th>AbM_I</th>
          <th>AbM_II</th>
          <th>Antacids</th>
          <th>AacidM_I</th>
          <th>AacidM_II</th>
          <th>Antihistamines</th>
          <th>AhistM_I</th>
          <th>AhistM_II</th>
          <th>Analgesics</th>
          <th>...</th>
          <th>AgesicM_II</th>
          <th>SulfaDrugs</th>
          <th>SulphaM_I</th>
          <th>SulphaM_II</th>
          <th>Antidepressents</th>
          <th>dpM_I</th>
          <th>dpM_II</th>
          <th>tranquilizers</th>
          <th>tranqM_I</th>
          <th>tranqM_II</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>Gentamicin</td>
          <td>404</td>
          <td>381</td>
          <td>Effervescents</td>
          <td>183</td>
          <td>300</td>
          <td>fexofenadine</td>
          <td>304</td>
          <td>245</td>
          <td>ibuprofen</td>
          <td>...</td>
          <td>28</td>
          <td>septra</td>
          <td>119</td>
          <td>121</td>
          <td>cymbalta</td>
          <td>70</td>
          <td>62</td>
          <td>trazodone</td>
          <td>24</td>
          <td>30</td>
        </tr>
        <tr>
          <th>1</th>
          <td>Amoxicillin/clavulanic_acid</td>
          <td>411</td>
          <td>116</td>
          <td>Algeldrate</td>
          <td>208</td>
          <td>279</td>
          <td>cetirizine</td>
          <td>74</td>
          <td>66</td>
          <td>legatrin</td>
          <td>...</td>
          <td>34</td>
          <td>gantrisin</td>
          <td>394</td>
          <td>453</td>
          <td>zoloft</td>
          <td>47</td>
          <td>47</td>
          <td>hydroxyzine</td>
          <td>28</td>
          <td>22</td>
        </tr>
        <tr>
          <th>2</th>
          <td>Ampicillin</td>
          <td>985</td>
          <td>906</td>
          <td>omeprazole</td>
          <td>7</td>
          <td>5</td>
          <td>terfenadine</td>
          <td>245</td>
          <td>212</td>
          <td>micrainin</td>
          <td>...</td>
          <td>45</td>
          <td>sulfafurazole</td>
          <td>443</td>
          <td>382</td>
          <td>lexapro</td>
          <td>61</td>
          <td>49</td>
          <td>Ativan</td>
          <td>33</td>
          <td>42</td>
        </tr>
        <tr>
          <th>3</th>
          <td>Aztreonam</td>
          <td>221</td>
          <td>229</td>
          <td>pantoprazole</td>
          <td>19</td>
          <td>25</td>
          <td>chloropheniramine</td>
          <td>395</td>
          <td>364</td>
          <td>phrenilin</td>
          <td>...</td>
          <td>36</td>
          <td>sulfafurazole</td>
          <td>426</td>
          <td>481</td>
          <td>bupropion</td>
          <td>56</td>
          <td>57</td>
          <td>lorazepam</td>
          <td>54</td>
          <td>59</td>
        </tr>
        <tr>
          <th>4</th>
          <td>Cefepime</td>
          <td>314</td>
          <td>524</td>
          <td>Nexium</td>
          <td>88</td>
          <td>69</td>
          <td>diphenhydramin</td>
          <td>210</td>
          <td>241</td>
          <td>asprin</td>
          <td>...</td>
          <td>46</td>
          <td>glipizide</td>
          <td>391</td>
          <td>380</td>
          <td>sertraline</td>
          <td>48</td>
          <td>48</td>
          <td>vistaril</td>
          <td>42</td>
          <td>26</td>
        </tr>
      </tbody>
    </table>
    <p>5 rows × 21 columns</p>
    </div>



.. code:: ipython3

    sns.set_style("whitegrid")
    sns.jointplot(x='AgesicM_I',y='AgesicM_II',data=df,kind='scatter')




.. parsed-literal::

    <seaborn.axisgrid.JointGrid at 0x1840ba52b70>




.. image:: output_3_1.png


.. code:: ipython3

    x=df['AgesicM_I']
    y=df['AgesicM_II']
    z=df['Analgesics']

.. code:: ipython3

    fig = plt.figure()
    ax = fig.add_axes([0,0,1,1])
    ax.plot(x,z,color='black',linewidth=2,linestyle='-',marker='v')
    ax.set_xlabel('Ranks in month  1')
    ax.set_ylabel('Analgesics')




.. parsed-literal::

    Text(0, 0.5, 'Analgesics')




.. image:: output_5_1.png


.. code:: ipython3

    sns.set_style("whitegrid")
    fig = plt.figure()
    ax = fig.add_axes([0,0,1,1])
    ax.plot(y,z,color='pink',linewidth=5,linestyle='-',marker='v')
    ax.set_xlabel('Ranks in month  1')
    ax.set_ylabel('Analgesics')




.. parsed-literal::

    Text(0, 0.5, 'Analgesics')




.. image:: output_6_1.png


.. code:: ipython3

    fig = plt.figure()
    ax = fig.add_subplot(111)
    
    numBins = 30
    ax.hist(x,numBins,color='orange',alpha=0.8)
    ax.set_xlabel('Analgesics rankings (first month)')
    plt.show()



.. image:: output_7_0.png


.. code:: ipython3

    sns.set_style("whitegrid")
    fig = plt.figure()
    ax = fig.add_subplot(111)
    
    numBins = 30
    ax.hist(y,numBins,color='blue',alpha=0.8)
    ax.set_xlabel('Analgesics rankings (second month)')
    plt.show()



.. image:: output_8_0.png


.. code:: ipython3

    sns.set_style("whitegrid")
    sns.countplot(x='AgesicM_I',data=df)




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x184182f0d30>




.. image:: output_9_1.png


.. code:: ipython3

    sns.countplot(x='AgesicM_II',data=df)




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x18418394160>




.. image:: output_10_1.png


.. code:: ipython3

    sns.set_style("whitegrid")
    sns.swarmplot(x='AgesicM_I',y='AgesicM_II',data=df)




.. parsed-literal::

    <matplotlib.axes._subplots.AxesSubplot at 0x18418412b38>




.. image:: output_11_1.png


